#ifndef VERSION_H
#define VERSION_H

#define PNET_VERSION_GIT "8d27a7b"

#if !defined(PNET_VERSION_BUILD) && defined(PNET_VERSION_GIT)
#define PNET_VERSION_BUILD PNET_VERSION_GIT
#endif

/* clang-format-off */

#define PNET_VERSION_MAJOR 0
#define PNET_VERSION_MINOR 1
#define PNET_VERSION_PATCH 0

#if defined(PNET_VERSION_BUILD)
#define PNET_VERSION \
   "0.1.0+"PNET_VERSION_BUILD
#else
#define PNET_VERSION \
   "0.1.0"
#endif

/* clang-format-on */

#endif /* VERSION_H */
